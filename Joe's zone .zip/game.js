
let player = { name: "" };
let squad = [];
let micOn = false;
let chatLog = [];
let stats = { matches: 0, wins: 0, headshots: 0 };

function startGame() {
  player.name = document.getElementById("playerName").value;
  if (!player.name) return alert("أدخل اسمك!");
  document.getElementById("displayName").innerText = player.name;
  document.getElementById("login").style.display = "none";
  document.getElementById("start-screen").style.display = "block";
}

function enterGame() {
  document.getElementById("start-screen").style.display = "none";
  document.getElementById("gameCanvas").style.display = "block";
}

function createSquad() {
  const id = document.getElementById("squadId").value;
  if (id) {
    squad = [player.name];
    alert("✅ أنشأت سكواد: " + id);
  }
}

function joinSquad() {
  const id = document.getElementById("squadId").value;
  if (id) {
    squad.push(player.name);
    alert("✅ انضممت للسكواد: " + id);
  }
}

function sendChat() {
  const msg = document.getElementById("chatMessage").value;
  if (msg) {
    chatLog.push(player.name + ": " + msg);
    document.getElementById("chatLog").innerText = chatLog.slice(-5).join("\n");
    document.getElementById("chatMessage").value = "";
  }
}

function createRoom() {
  const code = document.getElementById("roomCode").value;
  if (code) alert("✅ أنشأت روم: " + code);
}

function joinRoom() {
  const code = document.getElementById("roomCode").value;
  if (code) alert("✅ دخلت إلى الروم: " + code);
}

function updateStatsUI() {
  document.getElementById("statMatches").innerText = "Matches: " + stats.matches;
  document.getElementById("statWins").innerText = "Wins: " + stats.wins;
  document.getElementById("statHeadshots").innerText = "Headshots: " + stats.headshots;
}

window.onload = () => {
  updateStatsUI();
};
